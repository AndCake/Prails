id = arguments[0]

<- @getItem "<?=$arr_table['name']?>", id
