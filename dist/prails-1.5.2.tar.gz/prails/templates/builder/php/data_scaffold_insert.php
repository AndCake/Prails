$arr_data = func_get_arg(0);

return $this->add("<?=$arr_table['name']?>", $arr_data);