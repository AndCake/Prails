<h1><?=$arr_module["name"]?> Home</h1>

<p>This is the default entry event of your module. Change this however you like to.</p>