// your home handler code here...

$gen->setTitle("<?=$arr_module["name"]?> Home");

return out($arr_param);