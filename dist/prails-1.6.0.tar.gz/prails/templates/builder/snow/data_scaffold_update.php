id = arguments[0]
data = arguments[1]

@set "<?=$arr_table['name']?>", data, "<?=$arr_table['name']?>_id='{id}'"
