$id = func_get_arg(0);

return $this->getItem("<?=$arr_table['name']?>", $id);