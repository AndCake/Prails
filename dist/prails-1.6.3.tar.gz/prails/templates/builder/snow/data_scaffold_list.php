<- @get "<?=$arr_table['name']?>"
