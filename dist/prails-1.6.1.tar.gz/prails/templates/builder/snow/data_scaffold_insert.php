data = arguments[0]

<- @add "<?=$arr_table['name']?>", data
