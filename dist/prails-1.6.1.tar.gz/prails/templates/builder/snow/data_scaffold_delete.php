id = arguments[0]

@delete "<?=$arr_table['name']?>", "<?=$arr_table['name']?>_id='{id}'"
